# Posts fs module nodejs

```bash
 git clone https://github.com/Punithify/Q12-fs-posts-node.git
```

## Commands for CRUD

```bash
 node index.js  #create a posts directory
 node createPost.js  #create a blogPost.txt file
 node updatePost.js  #update the file
 node readPost.js  #read contents from the file
 node deletePost.js  #delete the post file
```
